import React, { useState, useEffect, useRef, useCallback, useMemo } from "react";
import {
  Camera, MapPin, BarChart3, MessageSquare, Bell, Sun, Moon, Menu, X,
  Trash2, AlertTriangle, Droplet, Lightbulb, Construction, CheckCircle2,
  Clock, TrendingUp, Users, Github, Linkedin, Mail, Send, ChevronRight,
  Upload, Loader2, ShieldCheck, Radar, ArrowRight, MapPinned,
  Activity, Sparkles, ChevronDown
} from "lucide-react";
import {
  PieChart, Pie, Cell, BarChart, Bar, LineChart, Line, XAxis, YAxis,
  CartesianGrid, Tooltip, ResponsiveContainer, Legend, AreaChart, Area
} from "recharts";

/* ============================================================
   AI COMMUNITY GUARDIAN
   Design system:
   - Deep slate/navy base (civic-infrastructure, not generic SaaS light)
   - Functional status colors from brief used ONLY as data/status accents
   - Display: Space Grotesk (technical/HUD) | Body: Inter | Data: JetBrains Mono
   - Signature motif: scanning reticle / bounding-box detection, echoed
     across hero, upload flow, and map pins
   ============================================================ */

const COLORS = {
  primary: "#2563EB",
  secondary: "#06B6D4",
  success: "#10B981",
  warning: "#F59E0B",
  danger: "#EF4444",
};

const FONT_LINK_ID = "acg-fonts";

function useFonts() {
  useEffect(() => {
    if (document.getElementById(FONT_LINK_ID)) return;
    const link = document.createElement("link");
    link.id = FONT_LINK_ID;
    link.rel = "stylesheet";
    link.href =
      "https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500;600&display=swap";
    document.head.appendChild(link);
  }, []);
}

/* ---------------- Mock data ---------------- */

const ISSUE_TYPES = [
  { key: "garbage", label: "Garbage", icon: Trash2, color: COLORS.warning },
  { key: "pothole", label: "Pothole", icon: Construction, color: COLORS.danger },
  { key: "water_leak", label: "Water Leakage", icon: Droplet, color: COLORS.secondary },
  { key: "streetlight", label: "Broken Streetlight", icon: Lightbulb, color: COLORS.primary },
  { key: "road_damage", label: "Road Damage", icon: AlertTriangle, color: COLORS.danger },
];

const PRIORITY_META = {
  High: { color: COLORS.danger, bg: "rgba(239,68,68,0.12)" },
  Medium: { color: COLORS.warning, bg: "rgba(245,158,11,0.12)" },
  Low: { color: COLORS.success, bg: "rgba(16,185,129,0.12)" },
};

const AREAS = ["Riverside District", "Oak Park", "Downtown Core", "Maple Heights", "Harbor View", "Elm Street"];

function seededRandom(seed) {
  let s = seed;
  return () => {
    s = (s * 9301 + 49297) % 233280;
    return s / 233280;
  };
}

function generateComplaints(n = 48) {
  const rnd = seededRandom(42);
  const statuses = ["Pending", "In Progress", "Resolved"];
  const out = [];
  for (let i = 0; i < n; i++) {
    const type = ISSUE_TYPES[Math.floor(rnd() * ISSUE_TYPES.length)];
    const priorityRoll = rnd();
    const priority = priorityRoll > 0.66 ? "High" : priorityRoll > 0.33 ? "Medium" : "Low";
    const status = statuses[Math.floor(rnd() * statuses.length)];
    const daysAgo = Math.floor(rnd() * 45);
    const date = new Date();
    date.setDate(date.getDate() - daysAgo);
    out.push({
      id: `CG-${String(1000 + i)}`,
      type: type.key,
      typeLabel: type.label,
      icon: type.icon,
      color: type.color,
      area: AREAS[Math.floor(rnd() * AREAS.length)],
      priority,
      status,
      date: date.toISOString().slice(0, 10),
      confidence: Math.floor(85 + rnd() * 14),
      lat: 28.6 + (rnd() - 0.5) * 0.12,
      lng: 77.2 + (rnd() - 0.5) * 0.12,
    });
  }
  return out.sort((a, b) => new Date(b.date) - new Date(a.date));
}

const COMPLAINTS = generateComplaints();

const MONTHLY = [
  { month: "Feb", reports: 62 },
  { month: "Mar", reports: 78 },
  { month: "Apr", reports: 94 },
  { month: "May", reports: 121 },
  { month: "Jun", reports: 108 },
  { month: "Jul", reports: 143 },
];

const DAILY = Array.from({ length: 14 }).map((_, i) => ({
  day: `D${i + 1}`,
  reports: Math.floor(6 + Math.sin(i / 2) * 4 + Math.random() * 5),
}));

const TEAM = [
  {
    name: "Sai Bighnesh Bahali",
    role: "Creator & Developer",
    email: "saibighneshbahali@gmail.com",
    github: "https://github.com/Bighnesh5",
    linkedin: "https://www.linkedin.com/in/sai-bighnesh-bahali-05799a370",
  },
];

/* ---------------- Mock AI classification service ----------------
   Clearly isolated so a real model (e.g. a vision endpoint) can be
   swapped in later without touching UI code. */
function mockClassifyImage(fileName = "") {
  const rnd = Math.random();
  const idx = Math.floor(rnd * ISSUE_TYPES.length);
  const type = ISSUE_TYPES[idx];
  const confidence = Math.floor(88 + Math.random() * 11);
  const priorityRoll = Math.random();
  const priority = priorityRoll > 0.62 ? "High" : priorityRoll > 0.3 ? "Medium" : "Low";
  const etaMap = { High: "2–4 hours", Medium: "1–2 days", Low: "3–5 days" };
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({
        type: type.key,
        typeLabel: type.label,
        icon: type.icon,
        color: type.color,
        confidence,
        priority,
        eta: etaMap[priority],
      });
    }, 1900);
  });
}

/* ---------------- Shared UI atoms ---------------- */

function GlassCard({ children, className = "", style = {}, hover = true }) {
  return (
    <div
      className={`acg-glass ${hover ? "acg-glass-hover" : ""} ${className}`}
      style={style}
    >
      {children}
    </div>
  );
}

function Badge({ children, color, bg }) {
  return (
    <span
      className="acg-badge"
      style={{ color, background: bg, borderColor: `${color}33` }}
    >
      {children}
    </span>
  );
}

function CountUp({ value, duration = 1200, suffix = "" }) {
  const [n, setN] = useState(0);
  const ref = useRef(null);
  const [inView, setInView] = useState(false);

  useEffect(() => {
    const obs = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) setInView(true);
      },
      { threshold: 0.3 }
    );
    if (ref.current) obs.observe(ref.current);
    return () => obs.disconnect();
  }, []);

  useEffect(() => {
    if (!inView) return;
    let start = null;
    function step(ts) {
      if (!start) start = ts;
      const progress = Math.min((ts - start) / duration, 1);
      setN(Math.floor(progress * value));
      if (progress < 1) requestAnimationFrame(step);
    }
    requestAnimationFrame(step);
  }, [inView, value, duration]);

  return (
    <span ref={ref}>
      {n}
      {suffix}
    </span>
  );
}

/* ---------------- Nav ---------------- */

function Nav({ page, setPage, dark, setDark }) {
  const [open, setOpen] = useState(false);
  const links = [
    { key: "home", label: "Home" },
    { key: "about", label: "About" },
    { key: "features", label: "Features" },
    { key: "report", label: "Report Issue" },
    { key: "dashboard", label: "Dashboard" },
    { key: "map", label: "Map" },
    { key: "analytics", label: "Analytics" },
    { key: "team", label: "Team" },
    { key: "contact", label: "Contact" },
  ];
  return (
    <header className="acg-nav">
      <div className="acg-nav-inner">
        <button className="acg-brand" onClick={() => setPage("home")}>
          <span className="acg-brand-mark">
            <Radar size={18} strokeWidth={2.4} />
          </span>
          <span className="acg-brand-text">
            AI Community <span style={{ color: COLORS.primary }}>Guardian</span>
          </span>
        </button>

        <nav className="acg-nav-links">
          {links.map((l) => (
            <button
              key={l.key}
              onClick={() => setPage(l.key)}
              className={`acg-nav-link ${page === l.key ? "active" : ""}`}
            >
              {l.label}
            </button>
          ))}
        </nav>

        <div className="acg-nav-actions">
          <button
            aria-label="Toggle dark mode"
            className="acg-icon-btn"
            onClick={() => setDark((d) => !d)}
          >
            {dark ? <Sun size={17} /> : <Moon size={17} />}
          </button>
          <button className="acg-btn-mobile" onClick={() => setOpen((o) => !o)}>
            {open ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
      </div>

      {open && (
        <div className="acg-mobile-menu">
          {links.map((l) => (
            <button
              key={l.key}
              onClick={() => {
                setPage(l.key);
                setOpen(false);
              }}
              className={`acg-mobile-link ${page === l.key ? "active" : ""}`}
            >
              {l.label}
            </button>
          ))}
        </div>
      )}
    </header>
  );
}

/* ---------------- Scan Reticle (signature visual motif) ---------------- */

function ScanReticle({ scanning = true, size = 340 }) {
  return (
    <div className="acg-reticle" style={{ width: size, height: size * 0.68 }}>
      <div className="acg-reticle-corner tl" />
      <div className="acg-reticle-corner tr" />
      <div className="acg-reticle-corner bl" />
      <div className="acg-reticle-corner br" />
      {scanning && <div className="acg-scanline" />}
      <div className="acg-reticle-grid" />
    </div>
  );
}

/* ---------------- HOME PAGE ---------------- */

function HomePage({ setPage }) {
  const stats = [
    { label: "Issues Detected", value: 3120, icon: Radar },
    { label: "Avg. Response", value: 6, suffix: "h", icon: Clock },
    { label: "Resolution Rate", value: 91, suffix: "%", icon: CheckCircle2 },
    { label: "Active Districts", value: 14, icon: MapPinned },
  ];

  return (
    <div>
      <section className="acg-hero">
        <div className="acg-hero-bg">
          <div className="acg-hero-grid" />
          <div className="acg-blob acg-blob-1" />
          <div className="acg-blob acg-blob-2" />
        </div>

        <div className="acg-hero-content">
          <div className="acg-hero-text">
            <div className="acg-eyebrow">
              <Sparkles size={13} />
              <span>Built for civic-tech · Smarter Communities</span>
            </div>
            <h1 className="acg-h1">
              AI Community <br />
              <span className="acg-gradient-text">Guardian</span>
            </h1>
            <p className="acg-subtitle">
              Making communities smarter with artificial intelligence — report civic
              issues in seconds, let AI classify and prioritize them, and watch your
              city respond faster.
            </p>
            <div className="acg-hero-actions">
              <button className="acg-btn-primary" onClick={() => setPage("report")}>
                <Camera size={17} />
                Report Issue
                <ArrowRight size={16} />
              </button>
              <button className="acg-btn-secondary" onClick={() => setPage("dashboard")}>
                <BarChart3 size={17} />
                View Dashboard
              </button>
            </div>
          </div>

          <div className="acg-hero-visual">
            <ScanReticle />
            <div className="acg-detect-tag tag-1">
              <Trash2 size={13} style={{ color: COLORS.warning }} />
              Garbage · 96%
            </div>
            <div className="acg-detect-tag tag-2">
              <Construction size={13} style={{ color: COLORS.danger }} />
              Pothole · 91%
            </div>
          </div>
        </div>
      </section>

      <section className="acg-section">
        <div className="acg-stats-grid">
          {stats.map((s, i) => (
            <GlassCard key={i} className="acg-stat-card">
              <s.icon size={20} style={{ color: COLORS.primary }} />
              <div className="acg-stat-value">
                <CountUp value={s.value} suffix={s.suffix || ""} />
              </div>
              <div className="acg-stat-label">{s.label}</div>
            </GlassCard>
          ))}
        </div>
      </section>

      <section className="acg-section">
        <div className="acg-section-head">
          <span className="acg-kicker">How it works</span>
          <h2 className="acg-h2">From photo to fixed, tracked at every step</h2>
        </div>
        <div className="acg-flow-grid">
          {[
            { icon: Camera, title: "Capture", desc: "Snap a photo of the issue — pothole, leak, broken light, or debris." },
            { icon: Radar, title: "Detect", desc: "AI classifies the issue type and scores its confidence in real time." },
            { icon: TrendingUp, title: "Prioritize", desc: "Severity and location determine urgency — High, Medium, or Low." },
            { icon: CheckCircle2, title: "Resolve", desc: "Authorities act, and citizens track status until it's marked resolved." },
          ].map((f, i) => (
            <GlassCard key={i} className="acg-flow-card">
              <div className="acg-flow-icon">
                <f.icon size={20} />
              </div>
              <h3 className="acg-flow-title">{f.title}</h3>
              <p className="acg-flow-desc">{f.desc}</p>
            </GlassCard>
          ))}
        </div>
      </section>
    </div>
  );
}

/* ---------------- ABOUT PAGE ---------------- */

function AboutPage() {
  const points = [
    {
      icon: Clock,
      title: "Reporting is slow today",
      desc: "Civic issues are reported through scattered phone calls, forms, and hallway conversations — with no shared record of severity or status.",
    },
    {
      icon: Camera,
      title: "A photo is the fastest signal",
      desc: "Citizens already take pictures of problems instinctively. We turn that instinct into a structured, actionable report in seconds.",
    },
    {
      icon: Radar,
      title: "AI reads the image",
      desc: "Computer vision classifies the issue type and estimates severity, removing guesswork from triage.",
    },
    {
      icon: TrendingUp,
      title: "Authorities act on data",
      desc: "Instead of a queue of unsorted complaints, teams see a prioritized, mapped, and measurable workload.",
    },
  ];
  return (
    <div className="acg-page">
      <div className="acg-section-head">
        <span className="acg-kicker">About the project</span>
        <h2 className="acg-h2">Fragmented reporting, meet structured response</h2>
        <p className="acg-section-desc">
          Most cities still rely on manual, disconnected channels to catch civic problems —
          a pothole here, a leak there, reported inconsistently and resolved even less
          consistently. AI Community Guardian closes that loop: citizens report with a photo,
          AI classifies and prioritizes it instantly, and authorities get a live, data-backed
          view of what needs attention first.
        </p>
      </div>

      <div className="acg-about-grid">
        {points.map((p, i) => (
          <GlassCard key={i} className="acg-about-card">
            <div className="acg-about-icon">
              <p.icon size={22} />
            </div>
            <div>
              <h3 className="acg-about-title">{p.title}</h3>
              <p className="acg-about-desc">{p.desc}</p>
            </div>
          </GlassCard>
        ))}
      </div>
    </div>
  );
}

/* ---------------- FEATURES PAGE ---------------- */

function FeaturesPage({ setPage }) {
  const features = [
    { icon: Radar, title: "AI Image Detection", desc: "Upload a photo and instantly classify garbage, potholes, water leakage, broken streetlights, or road damage." },
    { icon: TrendingUp, title: "Priority Prediction", desc: "Every report is automatically scored High, Medium, or Low priority based on severity signals." },
    { icon: MapPin, title: "Location Tracking", desc: "Capture GPS automatically or drop a pin manually to pinpoint the exact issue location." },
    { icon: BarChart3, title: "Analytics Dashboard", desc: "Real-time statistics on report volume, resolution rate, and response time across districts." },
    { icon: MessageSquare, title: "Citizen Chatbot", desc: "An always-on assistant that answers questions and guides citizens through reporting." },
    { icon: Bell, title: "Live Notifications", desc: "Status updates the moment a report moves from pending to in-progress to resolved." },
  ];
  return (
    <div className="acg-page">
      <div className="acg-section-head">
        <span className="acg-kicker">Capabilities</span>
        <h2 className="acg-h2">Everything a smart-community platform needs</h2>
      </div>
      <div className="acg-features-grid">
        {features.map((f, i) => (
          <GlassCard key={i} className="acg-feature-card">
            <div className="acg-feature-icon">
              <f.icon size={22} />
            </div>
            <h3 className="acg-feature-title">{f.title}</h3>
            <p className="acg-feature-desc">{f.desc}</p>
          </GlassCard>
        ))}
      </div>
      <div className="acg-cta-band">
        <div>
          <h3 className="acg-cta-title">Ready to see it in action?</h3>
          <p className="acg-cta-desc">Report a mock issue and watch the AI classify it in real time.</p>
        </div>
        <button className="acg-btn-primary" onClick={() => setPage("report")}>
          Try it now <ArrowRight size={16} />
        </button>
      </div>
    </div>
  );
}

/* ---------------- REPORT ISSUE PAGE ---------------- */

function ReportPage() {
  const [fileName, setFileName] = useState(null);
  const [previewUrl, setPreviewUrl] = useState(null);
  const [status, setStatus] = useState("idle"); // idle | analyzing | done
  const [result, setResult] = useState(null);
  const [description, setDescription] = useState("");
  const [location, setLocation] = useState("");
  const [submitted, setSubmitted] = useState(false);
  const fileInputRef = useRef(null);

  const handleFile = (file) => {
    if (!file) return;
    setFileName(file.name);
    setSubmitted(false);
    const url = URL.createObjectURL(file);
    setPreviewUrl(url);
    setStatus("analyzing");
    setResult(null);
    mockClassifyImage(file.name).then((res) => {
      setResult(res);
      setStatus("done");
    });
  };

  const handleUseLocation = () => {
    if (!navigator.geolocation) {
      setLocation("28.6139° N, 77.2090° E (fallback)");
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setLocation(`${pos.coords.latitude.toFixed(4)}° N, ${pos.coords.longitude.toFixed(4)}° E`);
      },
      () => setLocation("28.6139° N, 77.2090° E (fallback)")
    );
  };

  const canSubmit = status === "done" && location.trim().length > 0;

  return (
    <div className="acg-page">
      <div className="acg-section-head">
        <span className="acg-kicker">Report an issue</span>
        <h2 className="acg-h2">Upload a photo — AI takes it from there</h2>
      </div>

      <div className="acg-report-grid">
        <GlassCard className="acg-upload-card" hover={false}>
          <div
            className="acg-dropzone"
            onClick={() => fileInputRef.current?.click()}
            style={previewUrl ? { backgroundImage: `url(${previewUrl})` } : {}}
          >
            {!previewUrl && (
              <>
                <Upload size={28} style={{ color: COLORS.primary }} />
                <p className="acg-dropzone-text">Click to upload a photo</p>
                <p className="acg-dropzone-sub">JPG or PNG, up to 10MB</p>
              </>
            )}
            {status === "analyzing" && (
              <div className="acg-scan-overlay">
                <ScanReticle scanning size={280} />
                <div className="acg-analyzing-tag">
                  <Loader2 size={14} className="acg-spin" />
                  Analyzing image…
                </div>
              </div>
            )}
            {status === "done" && result && (
              <div className="acg-detected-tag" style={{ borderColor: `${result.color}55` }}>
                <result.icon size={14} style={{ color: result.color }} />
                {result.typeLabel} · {result.confidence}%
              </div>
            )}
          </div>
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            hidden
            onChange={(e) => handleFile(e.target.files?.[0])}
          />

          {status === "done" && result && (
            <div className="acg-ai-result">
              <div className="acg-ai-result-row">
                <span className="acg-ai-label">Issue Detected</span>
                <span className="acg-ai-value">{result.typeLabel}</span>
              </div>
              <div className="acg-ai-result-row">
                <span className="acg-ai-label">Confidence</span>
                <span className="acg-ai-value acg-mono">{result.confidence}%</span>
              </div>
              <div className="acg-ai-result-row">
                <span className="acg-ai-label">Priority</span>
                <Badge color={PRIORITY_META[result.priority].color} bg={PRIORITY_META[result.priority].bg}>
                  {result.priority}
                </Badge>
              </div>
              <div className="acg-ai-result-row">
                <span className="acg-ai-label">Est. Response</span>
                <span className="acg-ai-value acg-mono">{result.eta}</span>
              </div>
            </div>
          )}
        </GlassCard>

        <GlassCard className="acg-form-card" hover={false}>
          <label className="acg-field-label">Location</label>
          <div className="acg-location-row">
            <input
              className="acg-input"
              placeholder="e.g. 28.6139° N, 77.2090° E"
              value={location}
              onChange={(e) => setLocation(e.target.value)}
            />
            <button className="acg-btn-ghost-sm" onClick={handleUseLocation}>
              <MapPin size={15} /> Use GPS
            </button>
          </div>

          <label className="acg-field-label">Description</label>
          <textarea
            className="acg-textarea"
            placeholder="Add any helpful detail — how long has this been here, is it blocking access, etc."
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            rows={4}
          />

          <label className="acg-field-label">Issue Category (auto-filled by AI)</label>
          <div className="acg-readonly-field">
            {result ? result.typeLabel : "— Upload a photo to detect —"}
          </div>

          <label className="acg-field-label">Priority (AI generated)</label>
          <div className="acg-readonly-field">
            {result ? (
              <Badge color={PRIORITY_META[result.priority].color} bg={PRIORITY_META[result.priority].bg}>
                {result.priority}
              </Badge>
            ) : (
              "—"
            )}
          </div>

          <button
            className="acg-btn-primary acg-submit-btn"
            disabled={!canSubmit}
            onClick={() => setSubmitted(true)}
          >
            <Send size={16} />
            Submit Report
          </button>

          {submitted && (
            <div className="acg-success-banner">
              <CheckCircle2 size={18} style={{ color: COLORS.success }} />
              <div>
                <div className="acg-success-title">Complaint submitted successfully</div>
                <div className="acg-success-sub">
                  Reference #CG-{Math.floor(1000 + Math.random() * 8999)} · You'll get status updates as it progresses.
                </div>
              </div>
            </div>
          )}
        </GlassCard>
      </div>
    </div>
  );
}

/* ---------------- DASHBOARD PAGE ---------------- */

function DashboardPage() {
  const total = COMPLAINTS.length;
  const pending = COMPLAINTS.filter((c) => c.status === "Pending").length;
  const resolved = COMPLAINTS.filter((c) => c.status === "Resolved").length;
  const critical = COMPLAINTS.filter((c) => c.priority === "High").length;

  const pieData = ISSUE_TYPES.map((t) => ({
    name: t.label,
    value: COMPLAINTS.filter((c) => c.type === t.key).length,
    color: t.color,
  }));

  const cards = [
    { label: "Total Reports", value: total, icon: BarChart3, color: COLORS.primary },
    { label: "Pending", value: pending, icon: Clock, color: COLORS.warning },
    { label: "Resolved", value: resolved, icon: CheckCircle2, color: COLORS.success },
    { label: "Critical", value: critical, icon: AlertTriangle, color: COLORS.danger },
  ];

  const statusColor = (s) =>
    s === "Resolved" ? COLORS.success : s === "In Progress" ? COLORS.secondary : COLORS.warning;

  return (
    <div className="acg-page">
      <div className="acg-section-head">
        <span className="acg-kicker">Admin dashboard</span>
        <h2 className="acg-h2">Live view of every reported issue</h2>
      </div>

      <div className="acg-stats-grid">
        {cards.map((c, i) => (
          <GlassCard key={i} className="acg-stat-card">
            <c.icon size={20} style={{ color: c.color }} />
            <div className="acg-stat-value">
              <CountUp value={c.value} />
            </div>
            <div className="acg-stat-label">{c.label}</div>
          </GlassCard>
        ))}
      </div>

      <div className="acg-chart-grid">
        <GlassCard className="acg-chart-card" hover={false}>
          <h3 className="acg-chart-title">Issue Types</h3>
          <ResponsiveContainer width="100%" height={260}>
            <PieChart>
              <Pie data={pieData} dataKey="value" nameKey="name" innerRadius={55} outerRadius={90} paddingAngle={3}>
                {pieData.map((d, i) => (
                  <Cell key={i} fill={d.color} />
                ))}
              </Pie>
              <Tooltip contentStyle={{ background: "var(--acg-tooltip-bg)", border: "none", borderRadius: 10, fontSize: 13 }} />
              <Legend wrapperStyle={{ fontSize: 12 }} />
            </PieChart>
          </ResponsiveContainer>
        </GlassCard>

        <GlassCard className="acg-chart-card" hover={false}>
          <h3 className="acg-chart-title">Monthly Reports</h3>
          <ResponsiveContainer width="100%" height={260}>
            <BarChart data={MONTHLY}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--acg-grid)" />
              <XAxis dataKey="month" stroke="var(--acg-axis)" fontSize={12} />
              <YAxis stroke="var(--acg-axis)" fontSize={12} />
              <Tooltip contentStyle={{ background: "var(--acg-tooltip-bg)", border: "none", borderRadius: 10, fontSize: 13 }} />
              <Bar dataKey="reports" fill={COLORS.primary} radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </GlassCard>

        <GlassCard className="acg-chart-card acg-chart-wide" hover={false}>
          <h3 className="acg-chart-title">Daily Reports (last 14 days)</h3>
          <ResponsiveContainer width="100%" height={220}>
            <AreaChart data={DAILY}>
              <defs>
                <linearGradient id="areaFill" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor={COLORS.secondary} stopOpacity={0.4} />
                  <stop offset="100%" stopColor={COLORS.secondary} stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--acg-grid)" />
              <XAxis dataKey="day" stroke="var(--acg-axis)" fontSize={12} />
              <YAxis stroke="var(--acg-axis)" fontSize={12} />
              <Tooltip contentStyle={{ background: "var(--acg-tooltip-bg)", border: "none", borderRadius: 10, fontSize: 13 }} />
              <Area type="monotone" dataKey="reports" stroke={COLORS.secondary} fill="url(#areaFill)" strokeWidth={2} />
            </AreaChart>
          </ResponsiveContainer>
        </GlassCard>
      </div>

      <GlassCard className="acg-table-card" hover={false}>
        <h3 className="acg-chart-title">Recent Complaints</h3>
        <div className="acg-table-scroll">
          <table className="acg-table">
            <thead>
              <tr>
                <th>ID</th>
                <th>Issue</th>
                <th>Location</th>
                <th>Priority</th>
                <th>Status</th>
                <th>Date</th>
              </tr>
            </thead>
            <tbody>
              {COMPLAINTS.slice(0, 10).map((c) => (
                <tr key={c.id}>
                  <td className="acg-mono">{c.id}</td>
                  <td>
                    <span className="acg-table-issue">
                      <c.icon size={14} style={{ color: c.color }} />
                      {c.typeLabel}
                    </span>
                  </td>
                  <td>{c.area}</td>
                  <td>
                    <Badge color={PRIORITY_META[c.priority].color} bg={PRIORITY_META[c.priority].bg}>
                      {c.priority}
                    </Badge>
                  </td>
                  <td>
                    <span className="acg-status-dot" style={{ background: statusColor(c.status) }} />
                    {c.status}
                  </td>
                  <td className="acg-mono">{c.date}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </GlassCard>
    </div>
  );
}

/* ---------------- MAP PAGE ---------------- */

function MapPage() {
  const [selected, setSelected] = useState(null);
  const pinColor = (c) =>
    c.status === "Resolved" ? COLORS.success : c.priority === "High" ? COLORS.danger : COLORS.warning;

  const sample = COMPLAINTS.slice(0, 24);
  const minLat = Math.min(...sample.map((c) => c.lat));
  const maxLat = Math.max(...sample.map((c) => c.lat));
  const minLng = Math.min(...sample.map((c) => c.lng));
  const maxLng = Math.max(...sample.map((c) => c.lng));

  const project = (c) => ({
    left: `${((c.lng - minLng) / (maxLng - minLng)) * 84 + 8}%`,
    top: `${(1 - (c.lat - minLat) / (maxLat - minLat)) * 78 + 10}%`,
  });

  return (
    <div className="acg-page">
      <div className="acg-section-head">
        <span className="acg-kicker">Interactive map</span>
        <h2 className="acg-h2">Every report, mapped and color-coded</h2>
      </div>

      <div className="acg-map-legend">
        <span><span className="acg-status-dot" style={{ background: COLORS.danger }} /> High priority</span>
        <span><span className="acg-status-dot" style={{ background: COLORS.warning }} /> Medium priority</span>
        <span><span className="acg-status-dot" style={{ background: COLORS.success }} /> Resolved</span>
      </div>

      <GlassCard className="acg-map-card" hover={false}>
        <div className="acg-map-canvas">
          <div className="acg-map-grid-lines" />
          {sample.map((c) => {
            const pos = project(c);
            return (
              <button
                key={c.id}
                className="acg-pin"
                style={{ left: pos.left, top: pos.top, background: pinColor(c) }}
                onClick={() => setSelected(c)}
                title={c.typeLabel}
              >
                <span className="acg-pin-pulse" style={{ background: pinColor(c) }} />
              </button>
            );
          })}
        </div>
      </GlassCard>

      {selected && (
        <GlassCard className="acg-pin-detail" hover={false}>
          <div className="acg-pin-detail-head">
            <span className="acg-table-issue">
              <selected.icon size={16} style={{ color: selected.color }} />
              {selected.typeLabel}
            </span>
            <button className="acg-icon-btn" onClick={() => setSelected(null)}>
              <X size={16} />
            </button>
          </div>
          <div className="acg-ai-result-row">
            <span className="acg-ai-label">ID</span>
            <span className="acg-ai-value acg-mono">{selected.id}</span>
          </div>
          <div className="acg-ai-result-row">
            <span className="acg-ai-label">Area</span>
            <span className="acg-ai-value">{selected.area}</span>
          </div>
          <div className="acg-ai-result-row">
            <span className="acg-ai-label">Priority</span>
            <Badge color={PRIORITY_META[selected.priority].color} bg={PRIORITY_META[selected.priority].bg}>
              {selected.priority}
            </Badge>
          </div>
          <div className="acg-ai-result-row">
            <span className="acg-ai-label">Status</span>
            <span className="acg-ai-value">{selected.status}</span>
          </div>
          <div className="acg-ai-result-row">
            <span className="acg-ai-label">Reported</span>
            <span className="acg-ai-value acg-mono">{selected.date}</span>
          </div>
        </GlassCard>
      )}
    </div>
  );
}

/* ---------------- ANALYTICS PAGE ---------------- */

function AnalyticsPage() {
  const total = COMPLAINTS.length;
  const resolved = COMPLAINTS.filter((c) => c.status === "Resolved").length;
  const resolveRate = Math.round((resolved / total) * 100);

  const areaCounts = AREAS.map((a) => ({
    area: a,
    count: COMPLAINTS.filter((c) => c.area === a).length,
  })).sort((a, b) => b.count - a.count);

  const typeCounts = ISSUE_TYPES.map((t) => ({
    label: t.label,
    count: COMPLAINTS.filter((c) => c.type === t.key).length,
    color: t.color,
  })).sort((a, b) => b.count - a.count);

  const stats = [
    { label: "Avg. Response Time", value: "6.2h", icon: Clock },
    { label: "Resolved Rate", value: `${resolveRate}%`, icon: CheckCircle2 },
    { label: "Most Affected Area", value: areaCounts[0].area, icon: MapPinned },
    { label: "Most Common Issue", value: typeCounts[0].label, icon: Radar },
  ];

  return (
    <div className="acg-page">
      <div className="acg-section-head">
        <span className="acg-kicker">Analytics</span>
        <h2 className="acg-h2">What the data says about your city</h2>
      </div>

      <div className="acg-stats-grid">
        {stats.map((s, i) => (
          <GlassCard key={i} className="acg-stat-card">
            <s.icon size={20} style={{ color: COLORS.primary }} />
            <div className="acg-stat-value acg-stat-value-sm">{s.value}</div>
            <div className="acg-stat-label">{s.label}</div>
          </GlassCard>
        ))}
      </div>

      <div className="acg-chart-grid">
        <GlassCard className="acg-chart-card" hover={false}>
          <h3 className="acg-chart-title">Most Affected Areas</h3>
          <ResponsiveContainer width="100%" height={260}>
            <BarChart data={areaCounts} layout="vertical" margin={{ left: 20 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--acg-grid)" />
              <XAxis type="number" stroke="var(--acg-axis)" fontSize={12} />
              <YAxis type="category" dataKey="area" stroke="var(--acg-axis)" fontSize={11} width={100} />
              <Tooltip contentStyle={{ background: "var(--acg-tooltip-bg)", border: "none", borderRadius: 10, fontSize: 13 }} />
              <Bar dataKey="count" fill={COLORS.secondary} radius={[0, 6, 6, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </GlassCard>

        <GlassCard className="acg-chart-card" hover={false}>
          <h3 className="acg-chart-title">Monthly Trend</h3>
          <ResponsiveContainer width="100%" height={260}>
            <LineChart data={MONTHLY}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--acg-grid)" />
              <XAxis dataKey="month" stroke="var(--acg-axis)" fontSize={12} />
              <YAxis stroke="var(--acg-axis)" fontSize={12} />
              <Tooltip contentStyle={{ background: "var(--acg-tooltip-bg)", border: "none", borderRadius: 10, fontSize: 13 }} />
              <Line type="monotone" dataKey="reports" stroke={COLORS.primary} strokeWidth={2.5} dot={{ r: 4 }} />
            </LineChart>
          </ResponsiveContainer>
        </GlassCard>
      </div>
    </div>
  );
}

/* ---------------- TEAM PAGE ---------------- */

function TeamPage() {
  return (
    <div className="acg-page">
      <div className="acg-section-head">
        <span className="acg-kicker">Team</span>
        <h2 className="acg-h2">The person behind Guardian</h2>
      </div>
      <div className="acg-team-grid acg-team-grid-solo">
        {TEAM.map((m, i) => (
          <GlassCard key={i} className="acg-team-card">
            <div className="acg-team-avatar">{m.name.split(" ").map((n) => n[0]).join("")}</div>
            <h3 className="acg-team-name">{m.name}</h3>
            <p className="acg-team-role">{m.role}</p>
            <div className="acg-team-links">
              <a href={m.github} target="_blank" rel="noopener noreferrer" className="acg-icon-btn" aria-label="GitHub"><Github size={15} /></a>
              <a href={m.linkedin} target="_blank" rel="noopener noreferrer" className="acg-icon-btn" aria-label="LinkedIn"><Linkedin size={15} /></a>
              <a href={`mailto:${m.email}`} className="acg-icon-btn" aria-label="Email"><Mail size={15} /></a>
            </div>
          </GlassCard>
        ))}
      </div>
    </div>
  );
}

/* ---------------- CONTACT PAGE ---------------- */

function ContactPage() {
  const [sent, setSent] = useState(false);
  return (
    <div className="acg-page">
      <div className="acg-section-head">
        <span className="acg-kicker">Contact</span>
        <h2 className="acg-h2">Questions, feedback, or partnership ideas?</h2>
      </div>
      <div className="acg-contact-grid">
        <GlassCard className="acg-form-card" hover={false}>
          <label className="acg-field-label">Name</label>
          <input className="acg-input" placeholder="Your name" />
          <label className="acg-field-label">Email</label>
          <input className="acg-input" placeholder="you@example.com" />
          <label className="acg-field-label">Message</label>
          <textarea className="acg-textarea" rows={4} placeholder="How can we help?" />
          <button className="acg-btn-primary acg-submit-btn" onClick={() => setSent(true)}>
            <Send size={16} /> Send Message
          </button>
          {sent && (
            <div className="acg-success-banner">
              <CheckCircle2 size={18} style={{ color: COLORS.success }} />
              <div className="acg-success-title">Message sent — we'll be in touch soon.</div>
            </div>
          )}
        </GlassCard>

        <div className="acg-contact-info">
          <GlassCard className="acg-info-card">
            <Mail size={18} style={{ color: COLORS.primary }} />
            <div>
              <div className="acg-info-label">Company Email</div>
              <div className="acg-info-value">communityguardian.ai@gmail.com</div>
            </div>
          </GlassCard>
          <GlassCard className="acg-info-card">
            <Mail size={18} style={{ color: COLORS.secondary }} />
            <div>
              <div className="acg-info-label">Personal Email</div>
              <div className="acg-info-value">saibighneshbahali@gmail.com</div>
            </div>
          </GlassCard>
          <GlassCard className="acg-info-card">
            <Github size={18} style={{ color: COLORS.primary }} />
            <div>
              <div className="acg-info-label">GitHub</div>
              <div className="acg-info-value">github.com/Bighnesh5</div>
            </div>
          </GlassCard>
        </div>
      </div>
    </div>
  );
}

/* ---------------- FOOTER ---------------- */

function Footer({ setPage }) {
  return (
    <footer className="acg-footer">
      <div className="acg-footer-inner">
        <div>
          <div className="acg-brand" style={{ pointerEvents: "none" }}>
            <span className="acg-brand-mark"><Radar size={16} /></span>
            <span className="acg-brand-text">AI Community Guardian</span>
          </div>
          <p className="acg-footer-tag">Making communities smarter with AI.</p>
        </div>
        <div className="acg-footer-links">
          <button onClick={() => setPage("about")}>About</button>
          <button onClick={() => setPage("features")}>Features</button>
          <button onClick={() => setPage("dashboard")}>Dashboard</button>
          <button onClick={() => setPage("contact")}>Contact</button>
        </div>
      </div>
      <div className="acg-footer-bottom">
        © 2026 AI Community Guardian · Built for the Smarter Communities Hackathon
      </div>
    </footer>
  );
}

/* ---------------- CHATBOT ---------------- */

function Chatbot() {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState([
    { role: "bot", text: "Hi! I'm Guardian Assistant. Ask me how to report an issue, check a status, or how the AI works." },
  ]);
  const [input, setInput] = useState("");
  const scrollRef = useRef(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, open]);

  function respond(text) {
    const t = text.toLowerCase();
    if (t.includes("report")) {
      return "Go to the 'Report Issue' page, upload a photo, and add your location. Our AI classifies the issue and assigns a priority automatically.";
    }
    if (t.includes("status") || t.includes("complaint") || t.includes("track")) {
      return "You can track any complaint on the Dashboard or Map page using its reference ID, e.g. CG-1032.";
    }
    if (t.includes("ai") || t.includes("work") || t.includes("how does")) {
      return "Our AI analyzes your uploaded photo to detect the issue type (like a pothole or garbage pile), scores its confidence, and predicts a priority level based on severity.";
    }
    if (t.includes("priority")) {
      return "Priority is High, Medium, or Low — assigned automatically based on the detected issue type and severity signals in the photo.";
    }
    if (t.includes("hi") || t.includes("hello")) {
      return "Hello! Ask me about reporting an issue, tracking status, or how our AI detection works.";
    }
    return "I can help with: how to report an issue, where your complaint stands, or how the AI works. Try asking one of those!";
  }

  function send() {
    if (!input.trim()) return;
    const userMsg = { role: "user", text: input };
    const botMsg = { role: "bot", text: respond(input) };
    setMessages((m) => [...m, userMsg, botMsg]);
    setInput("");
  }

  return (
    <>
      <button className="acg-chat-fab" onClick={() => setOpen((o) => !o)} aria-label="Open chatbot">
        {open ? <X size={22} /> : <MessageSquare size={22} />}
      </button>
      {open && (
        <div className="acg-chat-window">
          <div className="acg-chat-head">
            <span className="acg-brand-mark" style={{ width: 28, height: 28 }}>
              <Radar size={14} />
            </span>
            Guardian Assistant
          </div>
          <div className="acg-chat-body" ref={scrollRef}>
            {messages.map((m, i) => (
              <div key={i} className={`acg-chat-msg ${m.role}`}>
                {m.text}
              </div>
            ))}
          </div>
          <div className="acg-chat-input-row">
            <input
              className="acg-chat-input"
              placeholder="Ask a question…"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && send()}
            />
            <button className="acg-icon-btn" onClick={send}><Send size={16} /></button>
          </div>
        </div>
      )}
    </>
  );
}

/* ---------------- ROOT APP ---------------- */

export default function App() {
  useFonts();
  const [page, setPage] = useState("home");
  const [dark, setDark] = useState(true);

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "instant" });
  }, [page]);

  const pages = {
    home: <HomePage setPage={setPage} />,
    about: <AboutPage />,
    features: <FeaturesPage setPage={setPage} />,
    report: <ReportPage />,
    dashboard: <DashboardPage />,
    map: <MapPage />,
    analytics: <AnalyticsPage />,
    team: <TeamPage />,
    contact: <ContactPage />,
  };

  return (
    <div className={dark ? "acg-root dark" : "acg-root"}>
      <style>{CSS}</style>
      <Nav page={page} setPage={setPage} dark={dark} setDark={setDark} />
      <main>{pages[page]}</main>
      <Footer setPage={setPage} />
      <Chatbot />
    </div>
  );
}

/* ================= CSS ================= */
const CSS = `
:root {
  --acg-bg: #F8FAFC;
  --acg-text: #0F172A;
  --acg-text-soft: #475569;
  --acg-card-bg: rgba(255,255,255,0.7);
  --acg-card-border: rgba(15,23,42,0.08);
  --acg-nav-bg: rgba(248,250,252,0.8);
  --acg-grid: #E2E8F0;
  --acg-axis: #64748B;
  --acg-tooltip-bg: #ffffff;
  --acg-input-bg: rgba(15,23,42,0.03);
  --acg-input-border: rgba(15,23,42,0.12);
}
.acg-root.dark {
  --acg-bg: #0B1120;
  --acg-text: #E2E8F0;
  --acg-text-soft: #94A3B8;
  --acg-card-bg: rgba(255,255,255,0.04);
  --acg-card-border: rgba(255,255,255,0.08);
  --acg-nav-bg: rgba(11,17,32,0.75);
  --acg-grid: #1E293B;
  --acg-axis: #64748B;
  --acg-tooltip-bg: #1E293B;
  --acg-input-bg: rgba(255,255,255,0.04);
  --acg-input-border: rgba(255,255,255,0.12);
}

* { box-sizing: border-box; }
.acg-root {
  font-family: 'Inter', sans-serif;
  background: var(--acg-bg);
  color: var(--acg-text);
  min-height: 100vh;
  transition: background 0.3s ease, color 0.3s ease;
  overflow-x: hidden;
}
.acg-mono { font-family: 'JetBrains Mono', monospace; }

/* ---------- Nav ---------- */
.acg-nav {
  position: sticky; top: 0; z-index: 50;
  background: var(--acg-nav-bg);
  backdrop-filter: blur(16px);
  border-bottom: 1px solid var(--acg-card-border);
}
.acg-nav-inner {
  max-width: 1200px; margin: 0 auto;
  display: flex; align-items: center; justify-content: space-between;
  padding: 14px 24px;
}
.acg-brand { display: flex; align-items: center; gap: 10px; background: none; border: none; cursor: pointer; }
.acg-brand-mark {
  width: 34px; height: 34px; border-radius: 10px;
  display: flex; align-items: center; justify-content: center;
  background: linear-gradient(135deg, #2563EB, #06B6D4);
  color: white;
}
.acg-brand-text { font-family: 'Space Grotesk', sans-serif; font-weight: 600; font-size: 16px; color: var(--acg-text); }
.acg-nav-links { display: flex; gap: 4px; }
.acg-nav-link {
  background: none; border: none; cursor: pointer;
  padding: 8px 12px; border-radius: 8px;
  font-size: 13.5px; font-weight: 500; color: var(--acg-text-soft);
  transition: all 0.2s ease; white-space: nowrap;
}
.acg-nav-link:hover { color: var(--acg-text); background: var(--acg-input-bg); }
.acg-nav-link.active { color: #2563EB; background: rgba(37,99,235,0.1); }
.acg-nav-actions { display: flex; align-items: center; gap: 8px; }
.acg-icon-btn {
  width: 34px; height: 34px; border-radius: 9px; border: 1px solid var(--acg-card-border);
  background: var(--acg-input-bg); color: var(--acg-text); cursor: pointer;
  display: flex; align-items: center; justify-content: center; transition: all 0.2s ease;
}
.acg-icon-btn:hover { border-color: #2563EB; color: #2563EB; }
.acg-btn-mobile { display: none; background: none; border: none; color: var(--acg-text); cursor: pointer; }
.acg-mobile-menu { display: none; flex-direction: column; padding: 8px 16px 16px; gap: 4px; }
.acg-mobile-link {
  text-align: left; background: none; border: none; padding: 10px 12px; border-radius: 8px;
  color: var(--acg-text-soft); font-size: 14px; cursor: pointer;
}
.acg-mobile-link.active { color: #2563EB; background: rgba(37,99,235,0.1); }

@media (max-width: 900px) {
  .acg-nav-links { display: none; }
  .acg-btn-mobile { display: block; }
  .acg-mobile-menu { display: flex; }
}

/* ---------- Glass card ---------- */
.acg-glass {
  background: var(--acg-card-bg);
  border: 1px solid var(--acg-card-border);
  border-radius: 16px;
  backdrop-filter: blur(12px);
  padding: 22px;
  transition: transform 0.25s ease, box-shadow 0.25s ease, border-color 0.25s ease;
}
.acg-glass-hover:hover {
  transform: translateY(-3px);
  box-shadow: 0 12px 32px rgba(37,99,235,0.12);
  border-color: rgba(37,99,235,0.3);
}

/* ---------- Hero ---------- */
.acg-hero { position: relative; padding: 64px 24px 40px; overflow: hidden; }
.acg-hero-bg { position: absolute; inset: 0; z-index: 0; }
.acg-hero-grid {
  position: absolute; inset: 0; opacity: 0.4;
  background-image: linear-gradient(var(--acg-grid) 1px, transparent 1px), linear-gradient(90deg, var(--acg-grid) 1px, transparent 1px);
  background-size: 48px 48px;
  mask-image: radial-gradient(ellipse at 30% 20%, black 0%, transparent 70%);
}
.acg-blob { position: absolute; border-radius: 50%; filter: blur(80px); opacity: 0.25; }
.acg-blob-1 { width: 420px; height: 420px; background: #2563EB; top: -100px; right: -80px; }
.acg-blob-2 { width: 300px; height: 300px; background: #06B6D4; bottom: -80px; left: 10%; }

.acg-hero-content {
  position: relative; z-index: 1;
  max-width: 1200px; margin: 0 auto;
  display: grid; grid-template-columns: 1.1fr 0.9fr; gap: 48px; align-items: center;
}
@media (max-width: 900px) { .acg-hero-content { grid-template-columns: 1fr; } }

.acg-eyebrow {
  display: inline-flex; align-items: center; gap: 6px;
  padding: 6px 12px; border-radius: 999px;
  background: rgba(37,99,235,0.1); color: #2563EB;
  font-size: 12.5px; font-weight: 600; margin-bottom: 20px;
  border: 1px solid rgba(37,99,235,0.2);
}
.acg-h1 {
  font-family: 'Space Grotesk', sans-serif; font-weight: 700;
  font-size: clamp(36px, 6vw, 60px); line-height: 1.05; margin: 0 0 20px;
  letter-spacing: -0.02em;
}
.acg-gradient-text {
  background: linear-gradient(135deg, #2563EB, #06B6D4);
  -webkit-background-clip: text; background-clip: text; color: transparent;
}
.acg-subtitle { font-size: 16.5px; color: var(--acg-text-soft); max-width: 480px; line-height: 1.6; margin-bottom: 32px; }
.acg-hero-actions { display: flex; gap: 12px; flex-wrap: wrap; }

.acg-btn-primary {
  display: inline-flex; align-items: center; gap: 8px;
  background: linear-gradient(135deg, #2563EB, #1D4ED8);
  color: white; border: none; padding: 13px 22px; border-radius: 12px;
  font-size: 14.5px; font-weight: 600; cursor: pointer;
  box-shadow: 0 8px 20px rgba(37,99,235,0.35);
  transition: transform 0.2s ease, box-shadow 0.2s ease;
}
.acg-btn-primary:hover { transform: translateY(-2px); box-shadow: 0 12px 28px rgba(37,99,235,0.45); }
.acg-btn-primary:disabled { opacity: 0.4; cursor: not-allowed; transform: none; box-shadow: none; }
.acg-btn-secondary {
  display: inline-flex; align-items: center; gap: 8px;
  background: var(--acg-input-bg); color: var(--acg-text);
  border: 1px solid var(--acg-input-border); padding: 13px 22px; border-radius: 12px;
  font-size: 14.5px; font-weight: 600; cursor: pointer; transition: all 0.2s ease;
}
.acg-btn-secondary:hover { border-color: #2563EB; color: #2563EB; }
.acg-btn-ghost-sm {
  display: inline-flex; align-items: center; gap: 6px; white-space: nowrap;
  background: var(--acg-input-bg); border: 1px solid var(--acg-input-border);
  color: var(--acg-text); padding: 10px 14px; border-radius: 10px; font-size: 13px;
  font-weight: 500; cursor: pointer; transition: all 0.2s ease;
}
.acg-btn-ghost-sm:hover { border-color: #2563EB; color: #2563EB; }

/* Hero visual / scan reticle */
.acg-hero-visual { position: relative; display: flex; align-items: center; justify-content: center; }
.acg-reticle {
  position: relative; border-radius: 20px;
  background: linear-gradient(135deg, rgba(37,99,235,0.15), rgba(6,182,212,0.1));
  border: 1px solid rgba(37,99,235,0.25);
  overflow: hidden;
}
.acg-reticle-grid {
  position: absolute; inset: 0;
  background-image: linear-gradient(rgba(37,99,235,0.15) 1px, transparent 1px), linear-gradient(90deg, rgba(37,99,235,0.15) 1px, transparent 1px);
  background-size: 24px 24px;
}
.acg-reticle-corner { position: absolute; width: 28px; height: 28px; border-color: #06B6D4; }
.acg-reticle-corner.tl { top: 10px; left: 10px; border-top: 3px solid; border-left: 3px solid; border-radius: 6px 0 0 0; }
.acg-reticle-corner.tr { top: 10px; right: 10px; border-top: 3px solid; border-right: 3px solid; border-radius: 0 6px 0 0; }
.acg-reticle-corner.bl { bottom: 10px; left: 10px; border-bottom: 3px solid; border-left: 3px solid; border-radius: 0 0 0 6px; }
.acg-reticle-corner.br { bottom: 10px; right: 10px; border-bottom: 3px solid; border-right: 3px solid; border-radius: 0 0 6px 0; }
.acg-scanline {
  position: absolute; left: 0; right: 0; height: 2px;
  background: linear-gradient(90deg, transparent, #06B6D4, transparent);
  box-shadow: 0 0 12px 2px #06B6D4;
  animation: acg-scan 2.4s ease-in-out infinite;
}
@keyframes acg-scan { 0%,100% { top: 8%; } 50% { top: 88%; } }

.acg-detect-tag {
  position: absolute; display: flex; align-items: center; gap: 6px;
  background: var(--acg-card-bg); backdrop-filter: blur(10px);
  border: 1px solid var(--acg-card-border); border-radius: 10px;
  padding: 8px 12px; font-size: 12.5px; font-weight: 600;
  box-shadow: 0 8px 20px rgba(0,0,0,0.15); animation: acg-float 4s ease-in-out infinite;
}
.tag-1 { top: -6px; right: 0; }
.tag-2 { bottom: 6px; left: -12px; animation-delay: 1.2s; }
@keyframes acg-float { 0%,100% { transform: translateY(0); } 50% { transform: translateY(-8px); } }

/* ---------- Sections ---------- */
.acg-section { max-width: 1200px; margin: 0 auto; padding: 56px 24px; }
.acg-page { max-width: 1200px; margin: 0 auto; padding: 48px 24px 64px; min-height: 60vh; }
.acg-section-head { max-width: 680px; margin-bottom: 40px; }
.acg-kicker { color: #2563EB; font-weight: 600; font-size: 12.5px; text-transform: uppercase; letter-spacing: 0.08em; }
.acg-h2 { font-family: 'Space Grotesk', sans-serif; font-size: clamp(26px, 4vw, 36px); font-weight: 600; margin: 10px 0 12px; letter-spacing: -0.01em; }
.acg-section-desc { color: var(--acg-text-soft); font-size: 15.5px; line-height: 1.7; }

.acg-stats-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 18px; }
@media (max-width: 800px) { .acg-stats-grid { grid-template-columns: repeat(2, 1fr); } }
.acg-stat-card { display: flex; flex-direction: column; gap: 8px; }
.acg-stat-value { font-family: 'Space Grotesk', sans-serif; font-size: 28px; font-weight: 700; }
.acg-stat-value-sm { font-size: 19px; }
.acg-stat-label { font-size: 13px; color: var(--acg-text-soft); }

.acg-flow-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 18px; margin-top: 32px; }
@media (max-width: 900px) { .acg-flow-grid { grid-template-columns: repeat(2, 1fr); } }
@media (max-width: 560px) { .acg-flow-grid { grid-template-columns: 1fr; } }
.acg-flow-icon {
  width: 44px; height: 44px; border-radius: 12px; margin-bottom: 14px;
  background: rgba(37,99,235,0.1); color: #2563EB;
  display: flex; align-items: center; justify-content: center;
}
.acg-flow-title { font-family: 'Space Grotesk', sans-serif; font-size: 16px; font-weight: 600; margin: 0 0 6px; }
.acg-flow-desc { font-size: 13.5px; color: var(--acg-text-soft); line-height: 1.55; margin: 0; }

/* About */
.acg-about-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 18px; }
@media (max-width: 700px) { .acg-about-grid { grid-template-columns: 1fr; } }
.acg-about-card { display: flex; gap: 16px; align-items: flex-start; }
.acg-about-icon {
  min-width: 46px; height: 46px; border-radius: 12px;
  background: rgba(6,182,212,0.1); color: #06B6D4;
  display: flex; align-items: center; justify-content: center;
}
.acg-about-title { font-family: 'Space Grotesk', sans-serif; font-size: 16px; font-weight: 600; margin: 0 0 6px; }
.acg-about-desc { font-size: 13.5px; color: var(--acg-text-soft); line-height: 1.6; margin: 0; }

/* Features */
.acg-features-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 18px; }
@media (max-width: 900px) { .acg-features-grid { grid-template-columns: repeat(2, 1fr); } }
@media (max-width: 560px) { .acg-features-grid { grid-template-columns: 1fr; } }
.acg-feature-icon {
  width: 46px; height: 46px; border-radius: 12px; margin-bottom: 14px;
  background: linear-gradient(135deg, rgba(37,99,235,0.15), rgba(6,182,212,0.1)); color: #2563EB;
  display: flex; align-items: center; justify-content: center;
}
.acg-feature-title { font-family: 'Space Grotesk', sans-serif; font-size: 16.5px; font-weight: 600; margin: 0 0 8px; }
.acg-feature-desc { font-size: 13.5px; color: var(--acg-text-soft); line-height: 1.6; margin: 0; }
.acg-cta-band {
  margin-top: 40px; padding: 28px 32px; border-radius: 18px;
  background: linear-gradient(135deg, rgba(37,99,235,0.12), rgba(6,182,212,0.08));
  border: 1px solid rgba(37,99,235,0.2);
  display: flex; align-items: center; justify-content: space-between; gap: 20px; flex-wrap: wrap;
}
.acg-cta-title { font-family: 'Space Grotesk', sans-serif; font-size: 18px; font-weight: 600; margin: 0 0 4px; }
.acg-cta-desc { font-size: 13.5px; color: var(--acg-text-soft); margin: 0; }

/* Report page */
.acg-report-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 24px; align-items: start; }
@media (max-width: 900px) { .acg-report-grid { grid-template-columns: 1fr; } }
.acg-dropzone {
  height: 260px; border-radius: 14px; border: 2px dashed var(--acg-input-border);
  display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 8px;
  cursor: pointer; position: relative; overflow: hidden; background-size: cover; background-position: center;
  transition: border-color 0.2s ease;
}
.acg-dropzone:hover { border-color: #2563EB; }
.acg-dropzone-text { font-size: 14px; font-weight: 600; margin: 0; }
.acg-dropzone-sub { font-size: 12px; color: var(--acg-text-soft); margin: 0; }
.acg-scan-overlay {
  position: absolute; inset: 0; background: rgba(11,17,32,0.55);
  display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 14px;
}
.acg-analyzing-tag {
  display: flex; align-items: center; gap: 8px; color: white; font-size: 13px; font-weight: 600;
  background: rgba(0,0,0,0.4); padding: 8px 14px; border-radius: 999px;
}
.acg-spin { animation: acg-spin 1s linear infinite; }
@keyframes acg-spin { to { transform: rotate(360deg); } }
.acg-detected-tag {
  position: absolute; bottom: 12px; left: 12px; display: flex; align-items: center; gap: 6px;
  background: rgba(11,17,32,0.8); border: 1px solid; color: white;
  padding: 7px 12px; border-radius: 999px; font-size: 12.5px; font-weight: 600;
}
.acg-ai-result { margin-top: 18px; display: flex; flex-direction: column; gap: 10px; }
.acg-ai-result-row { display: flex; align-items: center; justify-content: space-between; padding: 8px 0; border-bottom: 1px solid var(--acg-card-border); }
.acg-ai-result-row:last-child { border-bottom: none; }
.acg-ai-label { font-size: 13px; color: var(--acg-text-soft); }
.acg-ai-value { font-size: 13.5px; font-weight: 600; }
.acg-badge { display: inline-flex; padding: 4px 10px; border-radius: 999px; font-size: 12px; font-weight: 700; border: 1px solid; }

.acg-form-card { display: flex; flex-direction: column; }
.acg-field-label { font-size: 12.5px; font-weight: 600; color: var(--acg-text-soft); margin: 14px 0 6px; }
.acg-field-label:first-child { margin-top: 0; }
.acg-input, .acg-textarea {
  width: 100%; background: var(--acg-input-bg); border: 1px solid var(--acg-input-border);
  border-radius: 10px; padding: 11px 13px; font-size: 13.5px; color: var(--acg-text);
  font-family: 'Inter', sans-serif; resize: vertical;
}
.acg-input:focus, .acg-textarea:focus { outline: none; border-color: #2563EB; }
.acg-location-row { display: flex; gap: 8px; }
.acg-location-row .acg-input { flex: 1; }
.acg-readonly-field {
  background: var(--acg-input-bg); border: 1px solid var(--acg-input-border);
  border-radius: 10px; padding: 11px 13px; font-size: 13.5px; color: var(--acg-text-soft);
  display: flex; align-items: center;
}
.acg-submit-btn { margin-top: 20px; justify-content: center; width: 100%; }
.acg-success-banner {
  margin-top: 16px; display: flex; gap: 10px; align-items: flex-start;
  background: rgba(16,185,129,0.1); border: 1px solid rgba(16,185,129,0.25);
  border-radius: 12px; padding: 14px;
}
.acg-success-title { font-size: 13.5px; font-weight: 600; }
.acg-success-sub { font-size: 12px; color: var(--acg-text-soft); margin-top: 2px; }

/* Dashboard */
.acg-chart-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 18px; margin-top: 32px; }
@media (max-width: 900px) { .acg-chart-grid { grid-template-columns: 1fr; } }
.acg-chart-wide { grid-column: 1 / -1; }
.acg-chart-title { font-family: 'Space Grotesk', sans-serif; font-size: 15px; font-weight: 600; margin: 0 0 14px; }
.acg-table-card { margin-top: 18px; }
.acg-table-scroll { overflow-x: auto; }
.acg-table { width: 100%; border-collapse: collapse; font-size: 13px; }
.acg-table th { text-align: left; padding: 10px 12px; color: var(--acg-text-soft); font-weight: 600; font-size: 12px; text-transform: uppercase; letter-spacing: 0.03em; border-bottom: 1px solid var(--acg-card-border); }
.acg-table td { padding: 10px 12px; border-bottom: 1px solid var(--acg-card-border); white-space: nowrap; }
.acg-table-issue { display: flex; align-items: center; gap: 6px; font-weight: 500; }
.acg-status-dot { display: inline-block; width: 8px; height: 8px; border-radius: 50%; margin-right: 6px; }

/* Map */
.acg-map-legend { display: flex; gap: 20px; margin-bottom: 16px; font-size: 13px; color: var(--acg-text-soft); flex-wrap: wrap; }
.acg-map-legend span { display: flex; align-items: center; }
.acg-map-card { padding: 12px; }
.acg-map-canvas {
  position: relative; height: 420px; border-radius: 12px; overflow: hidden;
  background: linear-gradient(135deg, rgba(37,99,235,0.06), rgba(6,182,212,0.04));
}
.acg-map-grid-lines {
  position: absolute; inset: 0;
  background-image: linear-gradient(var(--acg-grid) 1px, transparent 1px), linear-gradient(90deg, var(--acg-grid) 1px, transparent 1px);
  background-size: 40px 40px; opacity: 0.6;
}
.acg-pin {
  position: absolute; width: 16px; height: 16px; border-radius: 50%;
  border: 2px solid white; cursor: pointer; transform: translate(-50%, -50%);
  box-shadow: 0 2px 8px rgba(0,0,0,0.3); z-index: 2;
}
.acg-pin-pulse {
  position: absolute; inset: -6px; border-radius: 50%; opacity: 0.4;
  animation: acg-pulse 2s ease-out infinite;
}
@keyframes acg-pulse { 0% { transform: scale(0.6); opacity: 0.5; } 100% { transform: scale(1.8); opacity: 0; } }
.acg-pin-detail { margin-top: 18px; max-width: 360px; }
.acg-pin-detail-head { display: flex; align-items: center; justify-content: space-between; margin-bottom: 12px; }

/* Team */
.acg-team-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 18px; }
@media (max-width: 900px) { .acg-team-grid { grid-template-columns: repeat(2, 1fr); } }
@media (max-width: 500px) { .acg-team-grid { grid-template-columns: 1fr; } }
.acg-team-grid-solo { grid-template-columns: minmax(240px, 320px); justify-content: flex-start; }
@media (max-width: 500px) { .acg-team-grid-solo { grid-template-columns: 1fr; } }
.acg-team-card { text-align: center; }
.acg-team-avatar {
  width: 64px; height: 64px; border-radius: 50%; margin: 0 auto 14px;
  background: linear-gradient(135deg, #2563EB, #06B6D4); color: white;
  display: flex; align-items: center; justify-content: center;
  font-family: 'Space Grotesk', sans-serif; font-weight: 700; font-size: 18px;
}
.acg-team-name { font-family: 'Space Grotesk', sans-serif; font-size: 15px; font-weight: 600; margin: 0 0 4px; }
.acg-team-role { font-size: 12.5px; color: var(--acg-text-soft); margin: 0 0 14px; }
.acg-team-links { display: flex; justify-content: center; gap: 8px; }

/* Contact */
.acg-contact-grid { display: grid; grid-template-columns: 1.4fr 1fr; gap: 20px; }
@media (max-width: 800px) { .acg-contact-grid { grid-template-columns: 1fr; } }
.acg-contact-info { display: flex; flex-direction: column; gap: 14px; }
.acg-info-card { display: flex; align-items: center; gap: 14px; }
.acg-info-label { font-size: 12px; color: var(--acg-text-soft); }
.acg-info-value { font-size: 14px; font-weight: 600; }

/* Footer */
.acg-footer { border-top: 1px solid var(--acg-card-border); margin-top: 40px; }
.acg-footer-inner {
  max-width: 1200px; margin: 0 auto; padding: 36px 24px 20px;
  display: flex; justify-content: space-between; align-items: flex-start; flex-wrap: wrap; gap: 20px;
}
.acg-footer-tag { font-size: 13px; color: var(--acg-text-soft); margin-top: 8px; }
.acg-footer-links { display: flex; gap: 20px; flex-wrap: wrap; }
.acg-footer-links button { background: none; border: none; color: var(--acg-text-soft); font-size: 13px; cursor: pointer; }
.acg-footer-links button:hover { color: #2563EB; }
.acg-footer-bottom { text-align: center; font-size: 12px; color: var(--acg-text-soft); padding: 16px 24px 28px; }

/* Chatbot */
.acg-chat-fab {
  position: fixed; bottom: 22px; right: 22px; width: 54px; height: 54px; border-radius: 50%;
  background: linear-gradient(135deg, #2563EB, #06B6D4); color: white; border: none; cursor: pointer;
  display: flex; align-items: center; justify-content: center; box-shadow: 0 10px 24px rgba(37,99,235,0.4);
  z-index: 60; transition: transform 0.2s ease;
}
.acg-chat-fab:hover { transform: scale(1.06); }
.acg-chat-window {
  position: fixed; bottom: 86px; right: 22px; width: 320px; height: 420px;
  background: var(--acg-tooltip-bg); border: 1px solid var(--acg-card-border);
  border-radius: 16px; box-shadow: 0 20px 50px rgba(0,0,0,0.25);
  display: flex; flex-direction: column; overflow: hidden; z-index: 60;
}
.acg-chat-head {
  padding: 14px 16px; font-weight: 600; font-size: 14px; display: flex; align-items: center; gap: 8px;
  border-bottom: 1px solid var(--acg-card-border); font-family: 'Space Grotesk', sans-serif;
}
.acg-chat-body { flex: 1; overflow-y: auto; padding: 14px 16px; display: flex; flex-direction: column; gap: 10px; }
.acg-chat-msg { max-width: 85%; padding: 9px 12px; border-radius: 12px; font-size: 13px; line-height: 1.5; }
.acg-chat-msg.bot { background: var(--acg-input-bg); align-self: flex-start; border-bottom-left-radius: 4px; }
.acg-chat-msg.user { background: #2563EB; color: white; align-self: flex-end; border-bottom-right-radius: 4px; }
.acg-chat-input-row { display: flex; gap: 8px; padding: 12px; border-top: 1px solid var(--acg-card-border); }
.acg-chat-input {
  flex: 1; background: var(--acg-input-bg); border: 1px solid var(--acg-input-border);
  border-radius: 10px; padding: 9px 12px; font-size: 13px; color: var(--acg-text);
}
.acg-chat-input:focus { outline: none; border-color: #2563EB; }

@media (max-width: 420px) {
  .acg-chat-window { width: calc(100vw - 32px); right: 16px; }
}
`;
